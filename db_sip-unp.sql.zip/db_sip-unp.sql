-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 18, 2015 at 10:07 PM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_sip-unp`
--

-- --------------------------------------------------------

--
-- Table structure for table `mst_anggota`
--

CREATE TABLE IF NOT EXISTS `mst_anggota` (
  `nim_nik` varchar(20) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `id_jurusan` varchar(10) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `no_kontak` varchar(15) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `status` varchar(1) NOT NULL,
  `foto` varchar(100) NOT NULL,
  PRIMARY KEY (`nim_nik`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_anggota`
--


-- --------------------------------------------------------

--
-- Table structure for table `mst_buku`
--

CREATE TABLE IF NOT EXISTS `mst_buku` (
  `id_buku` varchar(10) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `pengarang` varchar(50) NOT NULL,
  `penerbit` varchar(25) NOT NULL,
  `tahun_terbit` varchar(4) NOT NULL,
  `resensi` text NOT NULL,
  `id_kategori` varchar(10) NOT NULL,
  `id_rak` varchar(10) NOT NULL,
  `waktu_entry` date NOT NULL,
  `jumlah` int(11) NOT NULL,
  `cover` varchar(100) NOT NULL,
  PRIMARY KEY (`id_buku`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_buku`
--


-- --------------------------------------------------------

--
-- Table structure for table `mst_fakultas`
--

CREATE TABLE IF NOT EXISTS `mst_fakultas` (
  `id_fakultas` varchar(10) NOT NULL,
  `nama_fakultas` varchar(25) NOT NULL,
  PRIMARY KEY (`id_fakultas`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_fakultas`
--

INSERT INTO `mst_fakultas` (`id_fakultas`, `nama_fakultas`) VALUES
('fak-001', 'Fakultas Ilmu Komputer'),
('fak-002', 'Fakultas Ekonomi'),
('fak-003', 'Fakultas Sastra'),
('fak-004', 'Fakultas Psikologi');

-- --------------------------------------------------------

--
-- Table structure for table `mst_jurusan`
--

CREATE TABLE IF NOT EXISTS `mst_jurusan` (
  `id_jurusan` varchar(10) NOT NULL,
  `nama_jurusan` varchar(25) NOT NULL,
  `id_fakultas` varchar(10) NOT NULL,
  PRIMARY KEY (`id_jurusan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_jurusan`
--

INSERT INTO `mst_jurusan` (`id_jurusan`, `nama_jurusan`, `id_fakultas`) VALUES
('jur-001', 'Teknik Informatika', 'fak-001'),
('jur-002', 'Manajemen Informatika', 'fak-001'),
('jur-003', 'Akuntansi', 'fak-002'),
('jur-004', 'Manajemen', 'fak-002'),
('jur-005', 'Sastra Inggris', 'fak-003'),
('jur-006', 'Satra Jepang', 'fak-003'),
('jur-007', 'Psikologi', 'fak-004');

-- --------------------------------------------------------

--
-- Table structure for table `mst_kategori`
--

CREATE TABLE IF NOT EXISTS `mst_kategori` (
  `id_kategori` varchar(10) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_kategori`
--

INSERT INTO `mst_kategori` (`id_kategori`, `kategori`) VALUES
('KAT001', 'Pemrograman'),
('KAT002', 'Manajemen'),
('KAT003', 'Statistika'),
('KAT004', 'Akuntasi'),
('KAT005', 'Sastra'),
('KAT006', 'Ekonomi'),
('KAT007', 'Perbankan'),
('KAT008', 'Perpajakan'),
('KAT009', 'Agama Islam');

-- --------------------------------------------------------

--
-- Table structure for table `mst_pegawai`
--

CREATE TABLE IF NOT EXISTS `mst_pegawai` (
  `nik` varchar(15) NOT NULL,
  `nama_lengkap` varchar(50) DEFAULT NULL,
  `jenis_kelamin` varchar(10) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` text,
  `no_kontak` varchar(15) DEFAULT NULL,
  `tanggal_masuk` date DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `id_status` int(11) NOT NULL,
  PRIMARY KEY (`nik`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_pegawai`
--

INSERT INTO `mst_pegawai` (`nik`, `nama_lengkap`, `jenis_kelamin`, `tanggal_lahir`, `alamat`, `no_kontak`, `tanggal_masuk`, `foto`, `id_status`) VALUES
('0204121003', 'Irfan Rofie', '', '0000-00-00', '', '', '0000-00-00', '', 1),
('10022015201143', '', '', '0000-00-00', '', '', '0000-00-00', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `mst_rak`
--

CREATE TABLE IF NOT EXISTS `mst_rak` (
  `id_rak` varchar(10) NOT NULL,
  `nama_rak` varchar(100) NOT NULL,
  PRIMARY KEY (`id_rak`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_rak`
--

INSERT INTO `mst_rak` (`id_rak`, `nama_rak`) VALUES
('RAK001', 'RAK A.1'),
('RAK002', 'RAK A.2'),
('RAK003', 'RAK A.3'),
('RAK004', 'RAK A.4'),
('RAK005', 'RAK B.1'),
('RAK006', 'RAK B.2');

-- --------------------------------------------------------

--
-- Table structure for table `mst_status`
--

CREATE TABLE IF NOT EXISTS `mst_status` (
  `id_status` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(15) NOT NULL,
  PRIMARY KEY (`id_status`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `mst_status`
--

INSERT INTO `mst_status` (`id_status`, `status`) VALUES
(1, 'Administrator'),
(2, 'Petugas'),
(3, 'Dosen'),
(4, 'Karyawan'),
(5, 'Mahasiswa');

-- --------------------------------------------------------

--
-- Table structure for table `mst_user`
--

CREATE TABLE IF NOT EXISTS `mst_user` (
  `id_user` varchar(15) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nim_nik` varchar(15) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_user`
--

INSERT INTO `mst_user` (`id_user`, `username`, `password`, `nim_nik`) VALUES
('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', '0204121003');

-- --------------------------------------------------------

--
-- Table structure for table `trx_pinjam_kembali`
--

CREATE TABLE IF NOT EXISTS `trx_pinjam_kembali` (
  `id_transaksi` varchar(10) NOT NULL,
  PRIMARY KEY (`id_transaksi`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trx_pinjam_kembali`
--

